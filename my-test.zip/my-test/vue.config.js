const chalk = require('chalk');
const isTestEnv = process.env.VUE_APP_ENV === 'testing'; // 测试环境

const WTYT_CDN_ENV = '';
console.log(chalk.green('当前程序打包运行的环境为==========' + process.env.VUE_APP_ENV));

const distConfig = {
  outputDir: 'my-test/dist', // 打包文件夹，默认为dist
  publicPath: process.env.NODE_ENV === 'development' ? '/' : `${WTYT_CDN_ENV}/my-test/dist/`,
  assetsDir: 'V1.0.0',
  productionSourceMap: isTestEnv, // 该配置项用于设置是否为生产环境构建生成 source map，一般在生产环境下为了快速定位错误信息,开发环境或者测试环境为true,线上为false
  devServer: {
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
    // deServer 配置
    open: false, // 是否自动打开浏览器页面
    host: '0.0.0.0', // 指定使用一个 host。默认是 localhost
    port: 8500, // 端口地址
    https: false, // 使用https提供服务
  },
  crossorigin: 'anonymous',
  chainWebpack: (config) => {
    config.output.crossOriginLoading('anonymous');
    config.plugins.delete('prefetch').delete('preload');
  },
  css: {
    loaderOptions: {
      less: {},
    },
  },
};

const libConfig = {
  productionSourceMap: false, // 打包后不产生sourcemap
  css: {
    extract: true,
  },
  configureWebpack: (config) => {
    config.output.libraryExport = 'default';
  },
};

module.exports = process.env.VUE_APP_ENV === 'libBuilding' ? libConfig : distConfig;
